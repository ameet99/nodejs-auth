## Nodejs Authentication APP
Developed by Amit Bhavsar

## Technologies Used
1.  NodeJS
2.  Express
3.  EJS
4.  MongoDB
5.  Mongoose
6.  PassportJS
7.  JWT
8.  Nodemailer
9.  Bootstrap

## Prerequisites
- Git
- NodeJS


##### Installing NPM dependencies

`npm install`

##### Then simply start your app

`npm start`

